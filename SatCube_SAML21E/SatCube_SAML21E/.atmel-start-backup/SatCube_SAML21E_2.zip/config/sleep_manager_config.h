/* Auto-generated config file sleep_manager_config.h */
#ifndef SLEEP_MANAGER_CONFIG_H
#define SLEEP_MANAGER_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <<< end of configuration section >>>

#endif // SLEEP_MANAGER_CONFIG_H
