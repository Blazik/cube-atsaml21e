#include <atmel_start.h>

enum mcu_status {
	DEATH,
	RESET,
	SLEEP,
	SAT_READ,
	BLOCK_1_READ,
	BLOCK_2_READ,
	BLOCK_1_ERROR,
	BLOCK_2_ERROR,
};

int main(void)
{
	atmel_start_init();

	while (1) {
		
	}
}
