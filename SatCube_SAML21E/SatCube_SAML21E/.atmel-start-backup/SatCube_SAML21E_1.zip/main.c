#include <atmel_start.h>

int main(void)
{
	atmel_start_init();

	while (1) {
		
	}
}
