/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file or main.c
 * to avoid loosing it when reconfiguring.
 */
#include "driver_init.h"
#include "temperature_sensor_main.h"

static struct mcp980x    TEMPERATURE_SENSOR_descr_mcp; 

struct temperature_sensor *TEMPERATURE_SENSOR;
struct temperature_sensor *TEMPERATURE_mcp980x;

void read(){
	gpio_set_pin_level(BLOCK_1_EN, true);
	gpio_set_pin_level(BLOCK_1_EN, true);
	float x = temperature_sensor_read(&TEMPERATURE_mcp980x);
	delay_ms(1000);
}

/**
 * \brief Initialize Temperature Sensors
 */
void temperature_sensors_init(void)
{
	i2c_m_sync_enable(&I2C_OUT);
	TEMPERATURE_mcp980x = mcp980X_construct(&TEMPERATURE_SENSOR_descr_mcp.parent, &I2C_OUT, CONF_MCP980X_SENSOR_RESOLUTION);
	read();
}